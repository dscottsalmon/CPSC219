package application;

import javafx.fxml.FXML;
import javafx.scene.Node;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.event.ActionEvent;
import javafx.collections.FXCollections;
import javafx.application.Application;
import javafx.stage.Stage;
import javafx.scene.control.ChoiceBox;


public class SetupController {

    @FXML
    private Label weightUnitLabel;

    @FXML
    private Button enterButton;

    @FXML
    private Label goalUnitLabel;

    @FXML
    private Button metricButton;

    @FXML
    private Label heightUnitLabel;

    @FXML
    private TextField timeTextField;

    @FXML
    private TextField goalTextField;

    @FXML
    private Label validLabel;

    @FXML
    private TextField ageTextField;

    @FXML
    private TextField weightTextField;

    @FXML
    private Button clearButton;

    @FXML
    private TextField averageTextField;

    @FXML
    private Button imperialButton;

    @FXML
    private TextField heightTextField;

    @FXML
    private ChoiceBox<String> bodyTypeChoiceBox;

    @FXML
    private ChoiceBox<String> sexChoiceBox;
    
    PersonalInfo x = new PersonalInfo(0.0d, 0.0d, 20, "M", "none","empty string");
    private String[] sexList = {"M", "F"};
    private String[] activityList = {"none", "low", "moderate", "active", "very active"};
    public boolean typeMetric = false;
    
    
    @FXML
    void initialize() {
    	sexChoiceBox.setItems(FXCollections.observableArrayList(sexList));	
    	bodyTypeChoiceBox.setItems(FXCollections.observableArrayList(activityList));			
    	}
    
    @FXML
    void imperialButtonClicked(ActionEvent event) {
    	typeMetric = false;
    	heightUnitLabel.setText("inches");
    	weightUnitLabel.setText("lbs");
    	goalUnitLabel.setText("lbs");
    }

    @FXML
    void metricButtonClicked(ActionEvent event) {
    	typeMetric = true;
    	heightUnitLabel.setText("cm");
    	weightUnitLabel.setText("kg");
    	goalUnitLabel.setText("kg");
    }

    @FXML
    void clearButtonClicked(ActionEvent event) {
    	ageTextField.setText(null);
    	heightTextField.setText(null);
    	weightTextField.setText(null);
    	goalTextField.setText(null);
    	timeTextField.setText(null);
    	averageTextField.setText(null);
    	bodyTypeChoiceBox.getSelectionModel().select(-1);
    	sexChoiceBox.getSelectionModel().select(-1);
    }

    @FXML
    void enterButtonClicked(ActionEvent event) throws Exception {
    	boolean valid = true;

    	try {
	    	
    		if (sexChoiceBox.getSelectionModel().getSelectedIndex() ==-1 ||
	    		sexChoiceBox.getSelectionModel().getSelectedIndex() == 0 ||
	    		sexChoiceBox.getSelectionModel().getSelectedIndex() == 1) 	
	    	{
	    		x.setSex(sexChoiceBox.getSelectionModel().getSelectedItem()); 
	    		} else {
	    		valid = false;
	    		}
	    	
	    	if (ageTextField.getText().length() > 0 && isInt(ageTextField.getText()) == true &&
	    			ageTextField.getText().contains("-") == false) { //this does your age
	    		x.setAge(Integer.parseInt(ageTextField.getText()));
	    	} else {
	    		valid = false;
	    		ageTextField.setText(null);
	    	}
	    	
	    	if (heightTextField.getText().length() > 0 && isDouble(heightTextField.getText()) == true &&
	    			heightTextField.getText().contains("-") == false) { //this does your height
	    		 if (typeMetric == true) {
	    			 x.setHeight(Double.parseDouble(heightTextField.getText()));
	    		 } else {
	    			 x.setHeight(Double.parseDouble(heightTextField.getText())* 2.54d);
	    		 }
	    	} else {
	    		valid = false;
	    		heightTextField.setText(null);
	    	}
	    	
	    	if (weightTextField.getText().length() > 0 && isDouble(weightTextField.getText()) == true &&
	    			weightTextField.getText().contains("-") == false) { //this does your weight
	   		 	if (typeMetric == true) {
	   		 		x.setWeight(Double.parseDouble(weightTextField.getText())); 
	   		 	} else {
	   		 		x.setWeight(Double.parseDouble(weightTextField.getText()) * 0.453d);
	   		 	}
	    	} else {
	    		valid = false;
	    		weightTextField.setText(null);
	    	}
	    	
	    	if (goalTextField.getText().length() > 0 && isDouble(goalTextField.getText()) == true &&
	    			goalTextField.getText().contains("-") == false) { //this does your weight
	   		 	if (typeMetric == true) {
	   		 		x.setGoalWeight(Double.parseDouble(goalTextField.getText()));
	   		 	} else {
	   		 		x.setGoalWeight(Double.parseDouble(goalTextField.getText())* 0.453d);
	   		 	}
	    	} else {
	    		valid = false;
	    		goalTextField.setText(null);
	    	}
	    	
	    	if (timeTextField.getText().length() > 0 && isDouble(timeTextField.getText()) == true &&
	    			timeTextField.getText().contains("-") == false) { //this does your time
	   		 	x.setGoalTime(Double.parseDouble(timeTextField.getText())); 
	    	} else {
	    		valid = false;
	    		timeTextField.setText(null);
	    	}
	    	
	    	if (averageTextField.getText().length() > 0 && isDouble(averageTextField.getText()) == true &&
	    			averageTextField.getText().contains("-") == false) { //this does your time
	   		 	x.setAverageCalories(Double.parseDouble(averageTextField.getText()));
	    	} else {
	    		x.setAverageCalories(2000.0d);
	    		averageTextField.setText(null);
	    	}
	 
	    	if (bodyTypeChoiceBox.getSelectionModel().getSelectedIndex() > -1) {
	    		x.setActivityLevel(bodyTypeChoiceBox.getSelectionModel().getSelectedItem());
	    	} else {
	    		x.setActivityLevel("moderate");
	    		}
    	}catch(NullPointerException npe) {
    		
    	}
    	
    	if (x.getWeight() > x.getGoalWeight()) {
    		if (x.getGoalTime() < 12) {
    			x.setGoal("quick loss");
    			}else{
    				x.setGoal("loss");
    			}
    	} else if (x.getWeight() < x.getGoalWeight()) {
    		if (x.getGoalTime() < 12) {
    			x.setGoal("quick gain");
    		} else {
    			x.setGoal("gain"); }
    	} else {
    			x.setGoal("maintain");
    	}	
    	
    	if(valid){
    		x.calculateCalories();
    		x.calculateMacros();
			Application Visualization = new Visualization(x.calculateCalories(),x.calculateBMI(),
					x.calculateBMR(), x.getProtein(),x.getCarbs(),x.getFat());
			Stage window = (Stage) ((Node) event.getSource()).getScene().getWindow();
			Visualization.start(window);
    	
    	}else {
    		validLabel.setText("please enter all required information");
    	}
    		
    		
    }
    
    private boolean isInt(String input) {
		
	    boolean x = true;
	    try {
	        Integer.parseInt(input);
	    }catch (NumberFormatException e) {
	        x = false;
	    }
	    return x;
	}
    
    private boolean isDouble(String input) {
	
    	boolean x = true;
    	try {
    		Double.parseDouble(input);
    	}catch (NumberFormatException e) {
    		x = false;
    	}
    	return x;
    }
}

