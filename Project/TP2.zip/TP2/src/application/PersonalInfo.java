package application;

public class PersonalInfo {

	private double weight = 0.0d;
	private double height = 0.0d;
	private double goalWeight = 0.0d;
	private double goalTime = 1.0d;
	private double averageCalories = 2000.0d;
	private int age = 0;
	private String goal;
	private String sex;
	private String activityLevel;
	private double BMI;
	private double BMR;
	private int calories;
	private int protein;
	private int carbs;
	private int fat;
	
	PersonalInfo(double aWeight, double aHeight, int aAge, String aSex, String aActivityLevel, String aGoal){
	}
	
	public double calculateBMI() {
		BMI = Math.round(this.BMI = weight / height / height * 10000.0); 
		return BMI;
	}
	
	public double calculateBMR() {
		
		if (sex == "M") {
			BMR = (10 * weight) + (6.25 * height) - (5* age) + 5;
		} else {
			BMR = (10 * weight) + (6.25*height) - (5 * age) - 161;
		}
		return BMR;
	}
	
	private int goalDifference(String aGoal) {
		if(aGoal == "loss") return -250;
		else if(aGoal == "quick loss") return -500;
		else if(aGoal == "maintain") return 0;
		else if(aGoal == "gain") return 250;
		else if(aGoal == "quick gain") return 500;
		return 0;
	}
	
	
	 public int calculateCalories() {
		
		double maintenance = 0;
		if(sex == "M") 
			maintenance = Math.ceil((10 * weight) + (6.25 * height) - (5 * age) + 5);
		else if(sex == "F") 
			maintenance = Math.ceil((10 * weight) + (6.25 * height) - (5 * age) - 165);
		
		double activityFactor = 0;
		int goalFactor = 0;
		if(activityLevel == "none") {
			activityFactor = 1.2;
			goalFactor = goalDifference(goal);
		}
		else if(activityLevel == "low") {
			activityFactor = 1.375;
			goalFactor = goalDifference(goal);
		}
		else if(activityLevel == "moderate") {
			activityFactor = 1.55;
			goalFactor = goalDifference(goal);
		}
		else if(activityLevel == "active") {
			activityFactor = 1.725;
			goalFactor = goalDifference(goal);
		}
		else if(activityLevel == "very active") {
			activityFactor = 1.9;
			goalFactor = goalDifference(goal);
		}
		
		calories = (int)(maintenance * activityFactor + goalFactor);
		
		return calories;
	}
	 
	public void calculateMacros() {
		if(goal == "loss") {
			fat = (int)(calories * 0.20) / 9;
			carbs = (int)(calories * 0.55) / 4;
			protein = (int)(calories * 0.25) / 4;
		}
		
		else if(goal == "quick loss") {
			fat = (int)(calories * 0.25) / 9;
			carbs = (int)(calories * 0.45) / 4;
			protein = (int)(calories * 0.30) / 4;
		}
		
		else if(goal == "maintain") {
			fat = (int)(calories * 0.25) / 9;
			carbs = (int)(calories * 0.50) / 4;
			protein = (int)(calories * 0.25) / 4;
		}
		
		else if(goal == "gain") {
			fat = (int)(calories * 0.25) / 9;
			carbs = (int)(calories * 0.45) / 4;
			protein = (int)(calories * 0.30) / 4;
		}
		
		else if(goal == "quick gain") {
			fat = (int)(calories * 0.20) / 9;
			carbs = (int)(calories * 0.45) / 4;
			protein = (int)(calories * 0.35) / 4;
		}
		
	}
	
	public double getWeight() {
		return weight;
	}
	public void setWeight(double x) {
		this.weight = x;
	}
	public double getHeight() {
		return height;
	}
	public void setHeight(double x) {
		this.height = x;
	}

	public int getAge() {
		return age;
	}
	
	public void setAge(int x) {
		this.age = x;
	}

	public String getSex() {
		return sex;
	}
	public void setSex(String gender) {
		this.sex = gender;
	}

	public String getActivityLevel() {
		return activityLevel;
	}
	
	public void setActivityLevel(String x) {
		this.activityLevel = x;
	}

	public String getGoal() {
		return goal;
		}
	
	public void setGoal(String x) {
		this.goal = x;
		}
	public double getGoalWeight() {
		return goalWeight;
	}
	public void setGoalWeight(double x) {
		this.goalWeight = x;
	}
	public int getProtein() {
		return protein;
	}

	public int getCarbs() {
		return carbs;
	}

	public int getFat() {
		return fat;
	}
	
	public double getGoalTime() {
		return goalTime;
	}
	
	public void setGoalTime(double x) {
		this.goalTime = x;
	}
	
	public double getAverageCalories() {
		return averageCalories;
	}
	
	public void setAverageCalories(double x) {
		this.averageCalories = x;
	}

	public int getCalories() {
		return calories;
	}
}
