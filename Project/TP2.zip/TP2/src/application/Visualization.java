package application;


import javafx.application.Application;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.chart.PieChart;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;

public class Visualization extends Application{
	
	String textCals;
	String textBMI;
	String textBMR;
	String textCarbs;
	String textProts;
	String textFats;
	int pros;
	int carbs;
	int fats;
	
	
	Visualization(int cals, double BMI, double BMR, int pro, int carb, int fat){
		textCals = String.valueOf(cals);
		textBMI = String.valueOf(BMI);
		textBMR = String.valueOf(BMR);
		this.pros = pro;
		this.carbs = carb;
		this.fats = fat;
		textCarbs = String.valueOf(carb);
		textProts = String.valueOf(pro);
		textFats = String.valueOf(fat);
	}

	@Override
	public void start(Stage primaryStage) throws Exception {
		VBox root = new VBox();
		
		HBox chartBox = new HBox();
		ObservableList<PieChart.Data> pieChartData = 
				FXCollections.observableArrayList(
				new PieChart.Data("Carbs", carbs),
				new PieChart.Data("Protien", pros),
				new PieChart.Data("Fats", fats));
		final PieChart chart = new PieChart(pieChartData);
		chart.setTitle("Recommended Macronutrient Proportions" );
		
		chartBox.getChildren().add(chart);
		
		VBox calBox = new VBox();
		Label cals = new Label("Your daily calorie intake should be: " +  textCals);
		Label carbos = new Label("Your recommended daily carbohydrate goal is: " +  textCarbs + "g");
		Label prots = new Label("Your recommended daily protein goal is: " +  textProts + "g");
		Label fatos = new Label("Your recommended daily fat intake goal is: " +  textFats + "g");
		calBox.setAlignment(Pos.CENTER_LEFT);
		calBox.setSpacing(20);
		calBox.getChildren().add(cals);
		calBox.getChildren().add(carbos);
		calBox.getChildren().add(prots);
		calBox.getChildren().add(fatos);
		Button goBack = new Button("return");
		goBack.setOnAction(new ReturnButtonHandler());
		
		calBox.getChildren().add(goBack);
		
		chartBox.getChildren().add(calBox);
		
		root.getChildren().add(chartBox);
		
		HBox bmiBox = new HBox();
		Label BMI = new Label("     Your Body Mass Index is: " + textBMI);
		Label BMR = new Label("     Your Basal Metabolic Rate is: " + textBMR);
		
		
		bmiBox.getChildren().add(BMI);
		bmiBox.getChildren().add(BMR);
		
		root.getChildren().add(bmiBox);
		
		Scene scene = new Scene(root, 800, 500);
		
		primaryStage.setScene(scene);
		primaryStage.show();
		
	}

}
